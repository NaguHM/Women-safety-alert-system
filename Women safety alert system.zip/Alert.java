package womenSafetyAlertSystem;

import java.util.List;

abstract class Alert {
 abstract void sendAlert(List<Contact>contacts);
}
