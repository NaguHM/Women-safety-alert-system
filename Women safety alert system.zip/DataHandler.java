package womenSafetyAlertSystem;

import java.io.*;
import java.util.*;

public class DataHandler {
    private static final String FILE_NAME = "contacts.ser";
    
   // Save emergency contacts to file and synchronize the method to prevent multiple threads from modifying data at same time
    public synchronized static void saveContacts(List<Contact> contacts) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            oos.writeObject(contacts);
        } catch (IOException e) {
            System.out.println("Error saving contacts: " + e.getMessage());
        }
    }

    // Load emergency contacts from file
    @SuppressWarnings("unchecked")
    public synchronized static List<Contact> loadContacts() {
        File file = new File(FILE_NAME);
        if (!file.exists()) 
        	return new ArrayList<>();

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            return (List<Contact>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error loading contacts: " + e.getMessage());
        }
        return new ArrayList<>();
    }
}


