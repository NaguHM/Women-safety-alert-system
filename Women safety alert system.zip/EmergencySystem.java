package womenSafetyAlertSystem;

import java.util.*;

public class EmergencySystem {
    private static Scanner scanner = new Scanner(System.in);
    private static List<Contact> contacts = DataHandler.loadContacts();
    private static Alert alert = new SOSAlert(); // Polymorphism: Can switch to other alert types later

    public static void main(String[] args) {
        System.out.println("🔹 Women Safety Alert System 🔹");
        while (true) {
            System.out.println("\n1️⃣ Add Emergency Contact");
            System.out.println("2️⃣ View Contacts");
            System.out.println("3️⃣ Delete Emergency Contact"); // 🔥 New option added
            System.out.println("4️⃣ Trigger SOS Alert");
            System.out.println("5️⃣ Exit");
            System.out.print("Choose an option: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); 
            switch (choice) {
                case 1:
                    addContact();
                    break;
                case 2:
                    viewContacts();
                    break;
                case 3:
                    deleteContact(); // 🔥 Calls delete method
                    break;
                case 4:
                    triggerAlert();
                    break;
                case 5:
                    System.out.println("Exiting... Stay Safe! 🚀");
                    DataHandler.saveContacts(contacts);
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid option! Please try again.");
            }
        }
    }

    private static void addContact() {
        System.out.print("Enter Contact Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Phone Number: ");
        String phone = scanner.nextLine();
        contacts.add(new Contact(name, phone));
        DataHandler.saveContacts(contacts);
        System.out.println("✅ Contact added successfully!");
    }

    private static void viewContacts() {
        if (contacts.isEmpty()) {
            System.out.println("⚠ No emergency contacts saved.");
        } else {
            System.out.println("\n📜 Emergency Contacts:");
            for (Contact contact : contacts) {
                System.out.println(contact);
            }
        }
    }

    private static void deleteContact() { // 🔥 New method
        if (contacts.isEmpty()) {
            System.out.println("⚠ No emergency contacts to delete.");
            return;
        }

        System.out.print("Enter the name or phone number of the contact to delete: ");
        String input = scanner.nextLine();

        // Remove contact by matching name or phone number
        boolean removed = contacts.removeIf(contact -> 
            contact.getName().equalsIgnoreCase(input) || contact.getPhoneNumber().equals(input)
        );

        if (removed) {
            DataHandler.saveContacts(contacts); // Save updated list
            System.out.println("✅ Contact deleted successfully!");
        } else {
            System.out.println("❌ Contact not found!");
        }
    }

    private static void triggerAlert() {
        if (contacts.isEmpty()) {
            System.out.println("⚠ No emergency contacts found! Add contacts first.");
            return;
        }

        alert.sendAlert(contacts);
    }
}
