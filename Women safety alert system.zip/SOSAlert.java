package womenSafetyAlertSystem;

import java.util.List;

public class SOSAlert extends Alert {
	
	@Override
   public  void sendAlert(List<Contact> contacts) {
        if (contacts.isEmpty()) {
            System.out.println("⚠ No emergency contacts found! Add contacts first.");
            return;
        }

        //Multithreding:Alert is sent in a seperate thread without blocking other operations
        Thread alertThread=new 	Thread(() ->{
        	 StringBuilder message = new StringBuilder("\n🚨 EMERGENCY ALERT! 🚨\n");
        	 
              System.out.println("Message:HELP!");
        message.append("📩 Sending alert to all contacts:\n");

        for (Contact contact : contacts) {
        	
            message.append(contact.getName()).append(" (").append(contact.getPhoneNumber()).append("), ");
        }
        message.setLength(message.length() - 2); // Remove last comma and space
        message.append("\n✅ All contacts have been notified!");

        System.out.println(message);
    });
        alertThread.start();//start the new thread
	}
}

  